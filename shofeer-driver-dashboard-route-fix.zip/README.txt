SHOFEER Driver Dashboard Route Fix

Problem:
The old routes/driver.php is loaded after routes/web.php and can override
driver.dashboard with the legacy JSON dashboard route.

Fix:
bootstrap/app.php now re-registers the canonical /driver dashboard route last:
Driver\DashboardController@index

Install:
1) Expand-Archive .\shofeer-driver-dashboard-route-fix.zip -DestinationPath . -Force
2) php artisan optimize:clear
3) php artisan route:list --name=driver.dashboard
4) php artisan test tests/Feature/Driver/DriverDashboardEarningsTest.php

Expected route action:
App\Http\Controllers\Driver\DashboardController@index
