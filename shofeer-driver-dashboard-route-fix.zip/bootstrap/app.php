<?php

use App\Http\Controllers\Driver\DashboardController as DriverDashboardController;
use App\Http\Middleware\RoleMiddleware;
use App\Http\Middleware\VerifiedDriver;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

return Application::configure(
    basePath: dirname(__DIR__)
)
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',

        then: function (): void {
            /*
            |--------------------------------------------------------------------------
            | Admin Routes
            |--------------------------------------------------------------------------
            */

            Route::middleware('web')
                ->group(
                    base_path(
                        'routes/admin.php'
                    )
                );

            /*
            |--------------------------------------------------------------------------
            | Legacy Driver Routes
            |--------------------------------------------------------------------------
            |
            | Keep loading the existing driver routes so registration,
            | cars, trip requests and any older driver pages remain available.
            |
            */

            Route::middleware('web')
                ->group(
                    base_path(
                        'routes/driver.php'
                    )
                );

            /*
            |--------------------------------------------------------------------------
            | Driver Dashboard Compatibility Override
            |--------------------------------------------------------------------------
            |
            | routes/driver.php historically registered an older dashboard route
            | returning JSON. Because that file is loaded after routes/web.php,
            | it could override the new Stage 5.9 dashboard.
            |
            | Re-register the canonical /driver dashboard last so both its URI
            | and route name always resolve to Driver\DashboardController@index.
            |
            */

            Route::middleware([
                'web',
                'auth',
                'role:driver',
                'verified.driver',
            ])
                ->prefix('driver')
                ->name('driver.')
                ->group(
                    function (): void {
                        Route::get(
                            '/',
                            [
                                DriverDashboardController::class,
                                'index',
                            ]
                        )->name(
                            'dashboard'
                        );
                    }
                );
        }
    )
    ->withMiddleware(
        function (
            Middleware $middleware
        ): void {
            $middleware->alias([
                'role' =>
                    RoleMiddleware::class,

                'verified.driver' =>
                    VerifiedDriver::class,
            ]);
        }
    )
    ->withExceptions(
        function (
            Exceptions $exceptions
        ): void {
            $exceptions->shouldRenderJsonWhen(
                fn (Request $request) =>
                    $request->is('api/*')
                    || $request->expectsJson()
            );
        }
    )
    ->create();
