SHOFEER Route Fix V2

Fixes:
BadMethodCallException:
Method Illuminate\Routing\RouteRegistrar::view does not exist.

Cause:
Route::middleware('web')->view(...) is not a valid chain.

Correction:
The home Route::view() is now registered inside a middleware group closure.

Install:
1) Expand-Archive .\shofeer-route-home-driver-fix-v2.zip -DestinationPath . -Force
2) php artisan optimize:clear
3) php artisan route:list --name=home
4) php artisan route:list --name=driver.dashboard
5) php artisan test tests/Feature/Driver/DriverDashboardEarningsTest.php
