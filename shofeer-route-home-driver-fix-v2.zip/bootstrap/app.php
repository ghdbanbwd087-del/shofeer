<?php

use App\Http\Controllers\Driver\DashboardController as DriverDashboardController;
use App\Http\Middleware\RoleMiddleware;
use App\Http\Middleware\VerifiedDriver;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

return Application::configure(
    basePath: dirname(__DIR__)
)
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',

        then: function (): void {
            /*
            |--------------------------------------------------------------------------
            | Admin Routes
            |--------------------------------------------------------------------------
            */

            Route::middleware('web')
                ->group(
                    base_path('routes/admin.php')
                );

            /*
            |--------------------------------------------------------------------------
            | Legacy Driver Routes
            |--------------------------------------------------------------------------
            |
            | Keep loading the existing driver route file because older driver
            | registration / cars / trip request routes may still live there.
            |
            */

            Route::middleware('web')
                ->group(
                    base_path('routes/driver.php')
                );

            /*
            |--------------------------------------------------------------------------
            | Canonical Home Route
            |--------------------------------------------------------------------------
            |
            | routes/driver.php historically registered "/" and could override
            | the application's real home route. Register the canonical home
            | route after loading the legacy file.
            |
            */

            Route::middleware('web')
                ->group(
                    function (): void {
                        Route::view(
                            '/',
                            'home'
                        )->name(
                            'home'
                        );
                    }
                );

            /*
            |--------------------------------------------------------------------------
            | Canonical Driver Dashboard Route
            |--------------------------------------------------------------------------
            |
            | Register the Stage 5.9 driver dashboard last so the old JSON
            | dashboard route from routes/driver.php cannot override it.
            |
            */

            Route::middleware([
                'web',
                'auth',
                'role:driver',
                'verified.driver',
            ])
                ->prefix('driver')
                ->name('driver.')
                ->group(
                    function (): void {
                        Route::get(
                            '/',
                            [
                                DriverDashboardController::class,
                                'index',
                            ]
                        )->name(
                            'dashboard'
                        );
                    }
                );
        }
    )
    ->withMiddleware(
        function (
            Middleware $middleware
        ): void {
            $middleware->alias([
                'role' =>
                    RoleMiddleware::class,

                'verified.driver' =>
                    VerifiedDriver::class,
            ]);
        }
    )
    ->withExceptions(
        function (
            Exceptions $exceptions
        ): void {
            $exceptions->shouldRenderJsonWhen(
                fn (Request $request) =>
                    $request->is('api/*')
                    || $request->expectsJson()
            );
        }
    )
    ->create();
