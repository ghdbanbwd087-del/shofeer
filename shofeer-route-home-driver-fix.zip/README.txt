SHOFEER Route Fix - Home + Driver Dashboard

This fixes the current test failure:
Route [home] not defined.

Why:
routes/driver.php is a legacy route file loaded after routes/web.php.
It historically registered "/" and an old driver dashboard route, which can
replace canonical routes in Laravel's route collection.

This bootstrap/app.php keeps legacy driver routes available but re-registers,
last:
1) "/" as route name "home"
2) "/driver" as route name "driver.dashboard" -> Driver\DashboardController@index

Install:
Expand-Archive .\shofeer-route-home-driver-fix.zip -DestinationPath . -Force
php artisan optimize:clear
php artisan route:list --name=home
php artisan route:list --name=driver.dashboard
php artisan test tests/Feature/Driver/DriverDashboardEarningsTest.php
