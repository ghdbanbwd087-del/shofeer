<?php

use App\Http\Controllers\Driver\DashboardController as DriverDashboardController;
use App\Http\Middleware\RoleMiddleware;
use App\Http\Middleware\VerifiedDriver;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

return Application::configure(
    basePath: dirname(__DIR__)
)
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',

        then: function (): void {
            /*
            |--------------------------------------------------------------------------
            | Additional Route Files
            |--------------------------------------------------------------------------
            */

            Route::middleware('web')
                ->group(
                    base_path('routes/admin.php')
                );

            /*
             * Keep the legacy driver file loaded because older driver
             * registration / cars / trip request routes still live there.
             */
            Route::middleware('web')
                ->group(
                    base_path('routes/driver.php')
                );

            /*
            |--------------------------------------------------------------------------
            | Canonical Home Route
            |--------------------------------------------------------------------------
            |
            | The legacy driver route file historically registered "/" and could
            | replace the original root route in Laravel's route collection.
            | Register SHOFEER home last so both the "/" URI and the "home" name
            | are guaranteed to exist for shared Blade components.
            |
            */

            Route::middleware('web')
                ->view(
                    '/',
                    'home'
                )
                ->name('home');

            /*
            |--------------------------------------------------------------------------
            | Canonical Driver Dashboard Route
            |--------------------------------------------------------------------------
            |
            | The legacy driver file also had an old dashboard route. Register
            | the real Stage 5.9 dashboard last so driver.dashboard always points
            | to Driver\DashboardController@index.
            |
            */

            Route::middleware([
                'web',
                'auth',
                'role:driver',
                'verified.driver',
            ])
                ->prefix('driver')
                ->name('driver.')
                ->group(
                    function (): void {
                        Route::get(
                            '/',
                            [
                                DriverDashboardController::class,
                                'index',
                            ]
                        )->name('dashboard');
                    }
                );
        }
    )
    ->withMiddleware(
        function (
            Middleware $middleware
        ): void {
            $middleware->alias([
                'role' =>
                    RoleMiddleware::class,

                'verified.driver' =>
                    VerifiedDriver::class,
            ]);
        }
    )
    ->withExceptions(
        function (
            Exceptions $exceptions
        ): void {
            $exceptions->shouldRenderJsonWhen(
                fn (Request $request) =>
                    $request->is('api/*')
                    || $request->expectsJson()
            );
        }
    )
    ->create();
