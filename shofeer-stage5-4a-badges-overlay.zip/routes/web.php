<?php

use App\Http\Controllers\Auth\GoogleAuthController;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\Auth\LogoutController;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\BookingController;
use App\Http\Controllers\Passenger\BadgeController;
use App\Http\Controllers\Passenger\DashboardController;
use App\Http\Controllers\SeatController;
use App\Http\Controllers\TripController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Home
|--------------------------------------------------------------------------
*/

Route::view(
    '/',
    'home'
)->name(
    'home'
);

/*
|--------------------------------------------------------------------------
| Public Trips
|--------------------------------------------------------------------------
*/

Route::get(
    '/trips',
    [
        TripController::class,
        'index',
    ]
)->name(
    'trips.index'
);

Route::get(
    '/trips/{trip}',
    [
        TripController::class,
        'show',
    ]
)->name(
    'trips.show'
);

/*
|--------------------------------------------------------------------------
| Guest Authentication
|--------------------------------------------------------------------------
*/

Route::middleware(
    'guest'
)->group(
    function (): void {
        /*
        |--------------------------------------------------------------------------
        | Login
        |--------------------------------------------------------------------------
        */

        Route::get(
            '/login',
            [
                LoginController::class,
                'create',
            ]
        )->name(
            'login'
        );

        Route::post(
            '/login',
            [
                LoginController::class,
                'store',
            ]
        )
            ->middleware(
                'throttle:5,1'
            )
            ->name(
                'login.store'
            );

        /*
        |--------------------------------------------------------------------------
        | Passenger Registration
        |--------------------------------------------------------------------------
        */

        Route::get(
            '/register',
            [
                RegisterController::class,
                'create',
            ]
        )->name(
            'register'
        );

        Route::post(
            '/register',
            [
                RegisterController::class,
                'store',
            ]
        )
            ->middleware(
                'throttle:3,60'
            )
            ->name(
                'register.store'
            );

        /*
        |--------------------------------------------------------------------------
        | Google Authentication
        |--------------------------------------------------------------------------
        */

        Route::get(
            '/auth/google/redirect',
            [
                GoogleAuthController::class,
                'redirect',
            ]
        )
            ->middleware(
                'throttle:10,1'
            )
            ->name(
                'auth.google.redirect'
            );

        Route::get(
            '/auth/google/callback',
            [
                GoogleAuthController::class,
                'callback',
            ]
        )
            ->middleware(
                'throttle:10,1'
            )
            ->name(
                'auth.google.callback'
            );
    }
);

/*
|--------------------------------------------------------------------------
| Authenticated Routes
|--------------------------------------------------------------------------
*/

Route::middleware(
    'auth'
)->group(
    function (): void {
        /*
        |--------------------------------------------------------------------------
        | Logout
        |--------------------------------------------------------------------------
        */

        Route::post(
            '/logout',
            LogoutController::class
        )->name(
            'logout'
        );

        /*
        |--------------------------------------------------------------------------
        | Passenger Routes
        |--------------------------------------------------------------------------
        */

        Route::middleware(
            'role:passenger'
        )->group(
            function (): void {
                /*
                |--------------------------------------------------------------------------
                | Dashboard
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/dashboard',
                    [
                        DashboardController::class,
                        'index',
                    ]
                )->name(
                    'dashboard'
                );

                /*
                |--------------------------------------------------------------------------
                | Badges
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/dashboard/badges',
                    [
                        BadgeController::class,
                        'index',
                    ]
                )->name(
                    'dashboard.badges'
                );

                /*
                |--------------------------------------------------------------------------
                | My Bookings
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/dashboard/bookings',
                    [
                        DashboardController::class,
                        'bookings',
                    ]
                )->name(
                    'dashboard.bookings.index'
                );

                /*
                |--------------------------------------------------------------------------
                | Booking Details
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/dashboard/bookings/{booking}',
                    [
                        DashboardController::class,
                        'show',
                    ]
                )->name(
                    'dashboard.bookings.show'
                );

                /*
                |--------------------------------------------------------------------------
                | Cancel Unpaid Booking
                |--------------------------------------------------------------------------
                */

                Route::patch(
                    '/dashboard/bookings/{booking}/cancel',
                    [
                        DashboardController::class,
                        'cancel',
                    ]
                )
                    ->middleware(
                        'throttle:5,1'
                    )
                    ->name(
                        'dashboard.bookings.cancel'
                    );

                /*
                |--------------------------------------------------------------------------
                | Refund Request
                |--------------------------------------------------------------------------
                */

                Route::post(
                    '/dashboard/bookings/{booking}/refund',
                    [
                        DashboardController::class,
                        'requestRefund',
                    ]
                )
                    ->middleware(
                        'throttle:3,10'
                    )
                    ->name(
                        'dashboard.bookings.refund'
                    );

                /*
                |--------------------------------------------------------------------------
                | Seat Selection
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/trips/{trip}/seats',
                    [
                        SeatController::class,
                        'show',
                    ]
                )->name(
                    'trips.seats.show'
                );

                Route::post(
                    '/trips/{trip}/seats',
                    [
                        SeatController::class,
                        'store',
                    ]
                )
                    ->middleware(
                        'throttle:10,1'
                    )
                    ->name(
                        'trips.seats.store'
                    );

                /*
                |--------------------------------------------------------------------------
                | Payment
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/booking/{booking}/pay',
                    [
                        BookingController::class,
                        'pay',
                    ]
                )->name(
                    'booking.pay'
                );

                Route::post(
                    '/booking/{booking}/pay',
                    [
                        BookingController::class,
                        'submitPayment',
                    ]
                )
                    ->middleware(
                        'throttle:5,1'
                    )
                    ->name(
                        'booking.pay.submit'
                    );

                /*
                |--------------------------------------------------------------------------
                | Pending Payment
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/booking/{booking}/pending',
                    [
                        BookingController::class,
                        'pending',
                    ]
                )->name(
                    'booking.pending'
                );

                /*
                |--------------------------------------------------------------------------
                | Booking Success
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/booking/{booking}/success',
                    [
                        BookingController::class,
                        'success',
                    ]
                )->name(
                    'booking.success'
                );

                /*
                |--------------------------------------------------------------------------
                | Booking Failed
                |--------------------------------------------------------------------------
                */

                Route::get(
                    '/booking/{booking}/failed',
                    [
                        BookingController::class,
                        'failed',
                    ]
                )->name(
                    'booking.failed'
                );
            }
        );
    }
);
