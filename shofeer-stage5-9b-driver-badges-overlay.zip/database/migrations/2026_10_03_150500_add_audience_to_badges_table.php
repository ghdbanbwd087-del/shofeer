<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table(
            'badges',
            function (
                Blueprint $table
            ): void {
                $table
                    ->enum(
                        'audience',
                        [
                            'passenger',
                            'driver',
                        ]
                    )
                    ->default(
                        'passenger'
                    )
                    ->after(
                        'icon'
                    )
                    ->index();
            }
        );
    }

    public function down(): void
    {
        Schema::table(
            'badges',
            function (
                Blueprint $table
            ): void {
                $table->dropIndex([
                    'audience',
                ]);

                $table->dropColumn(
                    'audience'
                );
            }
        );
    }
};
